
public class ReporterFactory {

	public Reporter getCategory(String string) {
		if(string == null){
			return null;
		}		
		if(string.equalsIgnoreCase("category1")){
			return new category1();
        
		} 
		else if(string.equalsIgnoreCase("category2")){
			return new category2();
        
		} 
		else if(string.equalsIgnoreCase("category3")){
			return new category3();
			
		}
		else if(string.equalsIgnoreCase("category4")){
			return new category4();
			
		}
		else if(string.equalsIgnoreCase("category5")){
			return new category5();
			
		}
		else if(string.equalsIgnoreCase("category6")){
			return new category6();
			
		}
     
     return null;
		
		
	}
	
}
