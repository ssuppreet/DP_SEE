import java.util.ArrayList;


public class category1 implements Reporter{
	static int decider =0;
	

	@Override
	public void writeArticle() {
		System.out.println("Article has been written on Category 1");
		
	}
	static ArrayList<String> ar =new ArrayList<>(); 
	@Override
	public void add(String name,String type) {
		// TODO Auto-generated method stub
		ar.add(name);
		ar.add(type);
	}
	@Override
	public void notifyEveryone() {
		// TODO Auto-generated method stub
		int length=ar.size();
		for(int i=0;i<length;i=i+2)
		{	
			decider=1;
			
			
		}	
	}
	@Override
	public int Decider()
	{
		System.out.println("inside decider");
		return decider;
	}
	@Override
	public void addArticle(String article) {
		// TODO Auto-generated method stub
		
		
	}

}
