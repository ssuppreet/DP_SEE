
import java.util.Scanner;


public class NewsAgency {

		public static void main(String [] args)
		{

			Scanner in=new Scanner(System.in);
			String[] cats={"category1","category2","category3","category4","category5","category6"};
			boolean wish=true;
			ReporterFactory reporterFactory;

		    Reporter reporter;
			int option;
			String name;
			
			while(wish)
			{
				String type="";
				String[] s=new String[5];
				ReaderFactory readerFactory;
				Reader reader;
				String article;
				System.out.println("Enter 1 if you are a REPORTER \nEnter 2 if you are a READER \nEnter 3 to EXIT \n");
				option=in.nextInt();
				switch(option)
				{
				case 1:	System.out.println("Your name?");
						name=in.next();
						System.out.println("What type of article do you want to write?");
						for(String a: cats)
						{
							System.out.println(a);
						}	
						type=in.next();
						//System.out.println("Type the article: \n");
						//article=in.nextLine();
						reporterFactory = new ReporterFactory();
						reporter = reporterFactory.getCategory(type);
					    //reporter.writeArticle();
					    //reporter.addArticle(article);
					    reporter.notifyEveryone();
						break;
				case 2:	System.out.println("Enter 1 to subscribe \nEnter 2 to Logout ");
						option=in.nextInt();
						switch(option)
						{
						case 1: System.out.println("Your name?");
								name=in.next();
								String[] S=new String[5];
								readerFactory=new ReaderFactory();
								reader=readerFactory.getReader("premium",name);
								if(reader.check(name))
									type="premium";
								else
								{	
									System.out.println("normal case");
								reader=readerFactory.getReader("normal",name);
								if(reader.check(name))
									type="normal";
								}
								System.out.println("outside normal case");
								if(!(type.equals("")))
								{	System.out.println("in not equals");
									System.out.println(type);
									reader.add(name);
									System.out.println(type);
									reader= readerFactory.getReader(type,name);	
									S=reader.display(name);
									for(String a:S)
									{
										System.out.println(a);
										if((a!=(null)))
										{
											System.out.println("inside puneeth");
											reporterFactory = new ReporterFactory();
											reporter = reporterFactory.getCategory(a);
											System.out.println("got catgroy name");	
											int	d=reporter.Decider();
											if(d==1)
												System.out.println("New Article in "+a);
										}	
									}
									
								}
								if(type.equals(""))
								{		
									reader.add(name);
									System.out.println("What do you want to subcribe to? NORMAL or PREMIUM");
									type=in.next();
									reader=readerFactory.getReader(type,name);
								}
								boolean counter=reader.count();
								System.out.println(counter);
								if(counter)
								{	
									System.out.println("Enter the category");
									reader.attach(in.next());
								}
								else
								{
									System.out.println("You are not allowed to subscribe to other categories");
								}	
								
								break;
						case 2: wish=false;
								break;
						default:wish=false;
								break;
						} 
						break;
				case 3: wish=false;
						break;
				default:wish=false; 
						break;
				}
			}	
		}
}

