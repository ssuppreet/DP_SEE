
public interface Reader {
	public void add(String name);
	public String[] display(String name);
	public void update();
	public boolean check(String name); 
	public boolean count();
	public void attach(String Category);
}
