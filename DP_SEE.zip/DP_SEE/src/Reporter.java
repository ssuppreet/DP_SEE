
public interface Reporter {
	void writeArticle();

	void add(String name,String category);

	void notifyEveryone();

	void addArticle(String article);
	 int Decider();
}
