
public class ReaderFactory {
	public Reader getReader(String string,String name) {

	if(string == null){
		return null;
	}		
	if(string.equalsIgnoreCase("normal")){
		return new NormalReader(name);
    
	} 
	else if(string.equalsIgnoreCase("premium")){
		return new PremiumReader(name);
    
	} 
	return null;
}}
