import java.util.ArrayList;


public class PremiumReader implements Reader{
	String name;
	int count;
	String[] categories=new String[5];
	static ArrayList<String> ar =new ArrayList<>(); 

	public PremiumReader(String name)
	{
		this.name=name;
		count=0;
		for(int i=0;i<5;i++)
			categories[i]=null;
	}
	@Override
	public String[] display(String name) {
		// TODO Auto-generated method stub

		for(int i=0;i<5;i++)
			System.out.println(categories[i]);
		return categories;
	}

	@Override
	public void add(String name) {
		// TODO Auto-generated method stub
		ar.add(name);
		
		//System.out.println("add of pre");
	}
	
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean check(String name) {
		// TODO Auto-generated method stub
		for(int i=0;i<ar.size();i++)
		{
			if(ar.get(i).equals(name))
				return true;
		}
		return false;
	}
	@Override
	public boolean count() {
		// TODO Auto-generated method stub
		count++;
		if(count<5)
			return true;
		return false;
	}
	@Override
	public void attach(String category) {
		// TODO Auto-generated method stub
		categories[count]=category;
	}
	
}
