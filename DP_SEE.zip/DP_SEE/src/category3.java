import java.util.ArrayList;


public class category3 implements Reporter{
	static ArrayList<String> ar =new ArrayList<>();
	static int decider =0;
	@Override
	public void add(String name,String category) {
		// TODO Auto-generated method stub
		ar.add(name);
		ar.add(category);
	}

	@Override
	public void writeArticle() {
		System.out.println("Article has been written on Category 3");
		
	}

	@Override
	public int Decider()
	{
		return decider;
	}
	@Override
	public void notifyEveryone() {
		// TODO Auto-generated method stub
		int length=ar.size();
		for(int i=0;i<length;i++){	
			decider=1;
			System.out.println("Notified everone");
			
			
		}
	}

	@Override
	public void addArticle(String article) {
		// TODO Auto-generated method stub
		
	}

}
